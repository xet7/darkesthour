/*	$NetBSD: signal.h,v 1.5 1994/10/26 02:06:39 cgd Exp $	*/

#ifndef _MACHINE_SIGNAL_H_
#define _MACHINE_SIGNAL_H_

#include <m68k/signal.h>

#endif
