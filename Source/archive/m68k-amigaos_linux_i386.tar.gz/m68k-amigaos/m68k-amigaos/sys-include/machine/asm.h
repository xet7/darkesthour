/*	$NetBSD: asm.h,v 1.4 1994/10/26 02:05:57 cgd Exp $	*/

#ifndef _MACHINE_ASM_H_
#define _MACHINE_ASM_H_

#include <m68k/asm.h>

#endif
