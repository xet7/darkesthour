/* a little present for C++ .. */

#ifndef _VALUES_H
#define _VALUES_H

#include <float.h>
#include <limits.h>

#endif	/* _VALUES_H */


