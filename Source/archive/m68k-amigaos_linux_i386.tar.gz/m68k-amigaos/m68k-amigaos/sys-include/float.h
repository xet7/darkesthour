#ifndef _FLOAT_H
#define _FLOAT_H

#include <machine/float.h>

#endif
